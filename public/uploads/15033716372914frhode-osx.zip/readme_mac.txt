Copyright (C)2002-2010 by George Yohng / 4Front Technologies

To install, please copy .component file into /Library/Audio/Plug-ins/Components

To install as VST, rename from .component to .vst and copy to
/Library/Audio/Plug-ins/Vst

To install as RTAS, rename from .component to .dpm and copy to
/Library/Application Support/Digidesign/Plug-Ins

